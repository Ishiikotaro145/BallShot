﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shot : MonoBehaviour {

	public int moveType = -1;		//動きのタイプ
	public bool isRot;				//回転するか
	public bool isHeightMove;
	public bool isWidthMove;
	public float moveRange;

	//public float minRot;
	//public float maxRot;


	//移動に関するもの
	float moveAngle = 0.0f;//Sinカーブで使用


	//
	bool isHaveBall = false;		//ボールを保有しているか
	Vector3 shotVec = new Vector3();
	float shotPower = 0.3f;
	bool isAim = false;

	//回転に関係する変数
	float shotAngle = 0.0f;
	bool isUp = false;

	//ボールの管理用変数
	GameObject haveBall = null;

	//発車先のナビ
	public List<GameObject> pNaviList;


	// Use this for initialization
	void Start ()
	{
		shotVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * Vector3.up;

		//Debug.Log(shotVec);
	}
	
	// Update is called once per frame
	void Update () 
	{
		Rot ();

		Move ();

		Navi ();

		CheckTap ();

		if (isHaveBall == true)
		{
			if (haveBall != null)
			{
				haveBall.transform.position = new Vector3 (transform.position.x,transform.position.y,0.0f);
			}
		}
	}


	void Rot()
	{
		if (isAim == false)return;
		if (isRot == false)return;
		if (isHaveBall == false)return;

		if (isUp == false)
		{
			transform.Rotate (new Vector3(0,0,1.0f));
			shotAngle += 1.0f;
			if (shotAngle >= 45.0f) 
			{
				isUp = true;
			}

		}
		else
		{
			transform.Rotate (new Vector3(0,0,-1.0f));
			shotAngle -= 1.0f;
			if (shotAngle <= -45.0f)
			{
				isUp = false;
			}
		}
		Vector3 tmpVec = new Vector3 (0.0f,1.0f,0.0f);
		shotVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * tmpVec;


		//Debug.Log (transform.localEulerAngles.z);
	}


	void Move()
	{
		//if (isAim == false)return;
		if (StageManager.GetInstance.GetIsNext () == true)return;


		moveAngle += 0.05f;
		if (moveAngle >= 360.0f) 
		{
			moveAngle -= 360.0f;
		}

		if (isHeightMove == true) 
		{
			Vector3 v = transform.position;
			v.y = Mathf.Cos(moveAngle) * moveRange;
			transform.position = v;
		}
		if (isWidthMove == true) 
		{
			Vector3 v = transform.position;
			v.x = Mathf.Sin(moveAngle) * moveRange;
			transform.position = v;
		}





	}


	void Navi()
	{
		

		if (isHaveBall == false) 
		{
			for (int nCnt = 0; nCnt < pNaviList.Count; nCnt++) 
			{
				pNaviList [nCnt].transform.position = new Vector3 (transform.position.x,transform.position.y,0.0f);
			}
		}

		if (isAim == false)return;

		if (isHaveBall == false)return;

		Vector3 naviVec = new Vector3 ();
		naviVec = shotVec * shotPower;
		pNaviList [0].transform.position = new Vector3 (naviVec.x,naviVec.y,naviVec.z) + transform.position;
		naviVec.y -= 0.01f;

		for (int nCnt = 1; nCnt < pNaviList.Count; nCnt++) 
		{

			Vector3 tmpPos= pNaviList[nCnt - 1].transform.position;

			pNaviList [nCnt].transform.position = new Vector3 
				(
					tmpPos.x + naviVec.x,
					tmpPos.y + naviVec.y,
					tmpPos.z + naviVec.z
				);
			naviVec.y -= 0.01f;
		}
	}


	void CheckTap()
	{
		if (isHaveBall == false)return;

		if (Input.GetMouseButton (0) == true) 
		{
			isAim = true;
			Debug.Log ("AimNow");
		}




		//発車ベクトルをボールに教えてあげる。
		//ボール側のスクリプトにアクセス

		if (Input.GetMouseButtonUp (0) == false)return;

		Ball ballScript = haveBall.GetComponent<Ball>();
		ballScript.SetIsNowShot (true);
		ballScript.SetShotVec (shotVec * shotPower);

		isAim = false;
		isHaveBall = false;
		haveBall = null;
	}


	void OnTriggerEnter2D(Collider2D _other)
	{
		if (_other.transform.tag == "Player")
		{
			//ボールが発車台に触れた
			isHaveBall = true;
			haveBall = _other.gameObject;
			_other.gameObject.transform.position = new Vector3 (transform.position.x,transform.position.y,0.0f);

			//ボール側のスクリプトにアクセス
			Ball ballScript = _other.gameObject.GetComponent<Ball>();
			ballScript.SetIsNowShot (false);
			ballScript.SetBeforeShot (this.gameObject);
		}
	}





}
