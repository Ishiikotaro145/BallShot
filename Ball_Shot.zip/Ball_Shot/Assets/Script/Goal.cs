﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour {

	public int moveType = -1;		//動きのタイプ
	public bool isRot;				//回転するか

	bool isHaveBall = false;		//ボールを保有しているか
	Vector3 shotVec = new Vector3(); 
	float shotPower = 0.3f;
	bool isAim = false;

	//回転に関係する変数
	float shotAngle = 0.0f;
	bool isUp = false;

	//ボールの管理用変数
	GameObject haveBall = null;


	bool isGoal = false;
	int goalCnt = 0;

	public bool GetIsGoal(){ return isGoal; }


	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		Rot ();

		Move ();

		CheckTap ();


	}


	void Rot()
	{
		
		Vector3 tmpVec = new Vector3 (0.0f,1.0f,0.0f);
		shotVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * tmpVec;
		//return;

		if (isAim == false)return;
		if (isRot == false)return;
		if (isHaveBall == false)return;

		if (isUp == false)
		{
			transform.Rotate (new Vector3(0,0,1.0f));
			shotAngle += 1.0f;
			if (shotAngle >= 45.0f) 
			{
				isUp = true;
			}

		}
		else
		{
			transform.Rotate (new Vector3(0,0,-1.0f));
			shotAngle -= 1.0f;
			if (shotAngle <= -45.0f)
			{
				isUp = false;
			}
		}





		//Debug.Log (transform.localEulerAngles.z);
	}


	void Move()
	{
		
		if (isHaveBall == true)
		{
			haveBall.transform.position = new Vector3 (transform.position.x,transform.position.y,0.0f);
		}


	}


	void CheckTap()
	{
		if (isHaveBall == false)return;
		if (Input.GetMouseButton (0) == true) 
		{
			isAim = true;
			Debug.Log ("AimNow");
		}


		if (Input.GetMouseButtonUp (0) == false)return;

		//発車ベクトルをボールに教えてあげる。
		//ボール側のスクリプトにアクセス
		Ball ballScript = haveBall.GetComponent<Ball>();
		ballScript.SetIsNowShot (true);
		ballScript.SetShotVec (shotVec * shotPower);

		isAim = false;
		isHaveBall = false;
		haveBall = null;
	}


	void OnTriggerEnter2D(Collider2D _other)
	{
		if (_other.transform.tag == "Player")
		{
			//ボールが発車台に触れた
			isHaveBall = true;
			isGoal = true;
			haveBall = _other.gameObject;
			_other.gameObject.transform.position = new Vector3 (transform.position.x,transform.position.y,0.0f);

			//ボール側のスクリプトにアクセス
			Ball ballScript = _other.gameObject.GetComponent<Ball>();
			ballScript.SetIsNowShot (false);
			ballScript.SetBeforeShot (this.gameObject);
		}



		if (_other.transform.tag == "Player" && goalCnt == 0)
		{
			StageManager.GetInstance.SetNextStage ();

			goalCnt++;
			Debug.Log ("ゴールに触れた");
		}




	}
}
