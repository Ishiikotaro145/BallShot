﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OneStage : MonoBehaviour {

	public GameObject pGoalObject;

	const float defMoveSpeed = 8.0f;
	bool isMove = false;			//trueの時に、ステージを下にスクロールさせる
	float moveSpeed;
	Vector3 afterPos = new Vector3();
	int goalCnt = 0;


	void SetMoveTrue()
	{
		isMove = true;
		afterPos = new Vector3 (transform.position.x,transform.position.y - defMoveSpeed,0.0f);
		moveSpeed = defMoveSpeed;

		//マネージャーに移動する事を教えてあげる。
		StageManager.GetInstance.TellMove(true);
	}


	// Use this for initialization
	void Start ()
	{
		moveSpeed = defMoveSpeed;
		afterPos = new Vector3 (transform.position.x,transform.position.y - defMoveSpeed,0.0f);
		isMove = true;

		//マネージャーに移動する事を教えてあげる。
		StageManager.GetInstance.TellMove(true);

	}
	
	// Update is called once per frame
	void Update () 
	{
		//Move ();

		//各ステージのゴールに到達したら。
		if (pGoalObject.GetComponent<Goal> ().GetIsGoal () == true && isMove == false && goalCnt == 0) 
		{
			SetMoveTrue ();
			goalCnt++;
			Debug.Log ("GOAL!!");
		}



	}


	public void Move()
	{

		//スライド移動
		transform.position = new Vector3 (transform.position.x,afterPos.y + moveSpeed,0.0f);


		moveSpeed -= 0.2f;
		if (moveSpeed > 0.001f)return;

		isMove = false;
		//マネージャーに移動が終わった事を伝える。(やりすぎるとズレるかも、、、)


		StageManager.GetInstance.TellMove (false);

		//再スクロール設定
		moveSpeed = defMoveSpeed;
		afterPos = new Vector3 (transform.position.x,transform.position.y - defMoveSpeed,0.0f);

		//transform.position = new Vector3 (afterPos.x,afterPos.y,afterPos.z);

	}

}
