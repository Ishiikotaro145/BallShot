﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wind : MonoBehaviour {

	public List<GameObject> pWindPrefab;


	Vector3 moveVec = new Vector3(0.0f,1.0f,0.0f);


	// Use this for initialization
	void Start () 
	{
		moveVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * moveVec;


	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}


	void OnTriggerStay2D(Collider2D _other)
	{
		if (_other.transform.tag == "Player")
		{
			//ボール側のスクリプトにアクセス
			Ball ballScript = _other.gameObject.GetComponent<Ball>();




			ballScript.AddUpVec (moveVec);
			//ballScript.DivVecX ();

		}
	}
}
