﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour {


	public bool isMove;
	public int moveType;

	float moveAngle = 0.0f;





	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		Move ();


	}


	void Move()
	{
		if (isMove == false)return;

		switch (moveType) 
		{
		case 0:
			moveAngle += 0.05f;
			if (moveAngle >= 360.0f) 
			{
				moveAngle -= 360.0f;
			}

			Vector3 v = transform.position;
			v.x = Mathf.Sin(moveAngle) * 2.0f;
			transform.position = v;
			break;
		case 1:

			break;
		case 2:

			break;
		}



	}
}
