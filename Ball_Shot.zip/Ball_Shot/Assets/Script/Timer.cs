﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {

	public Text pTimerText;

	float LimitTime = 30.0f;


	public void AddTime( float _addTime ){ LimitTime += _addTime; }

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (LimitTime > 0.0f) 
		{
			LimitTime -= Time.deltaTime;
		}
		else
		{
			LimitTime = 0.0f;
		}


		pTimerText.text = (LimitTime).ToString();

	}
}
