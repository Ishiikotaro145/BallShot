﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {

	Vector3 shotVec = new Vector3();

	float gravity = 0.01f;
	bool isNowShot = true;
	GameObject BeforeShot = null;

	public bool GetIsNowShot(){ return isNowShot; }

	public void SetIsNowShot(bool _flg){ isNowShot = _flg; }
	public void SetShotVec(Vector3 _shotVec){ shotVec = _shotVec; }
	public void SetBeforeShot(GameObject _shotObject){ BeforeShot = _shotObject; }


	public void AddVec(Vector3 _vec) {shotVec += (_vec * 0.02f);}
	public void DivVecX(){ shotVec.x *= 0.9f; }



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		LostBall ();

		if (isNowShot == false)return;

		transform.position += new Vector3 (shotVec.x,shotVec.y,shotVec.z);

		shotVec.y -= gravity;
	}


	void LostBall()
	{
		if (transform.position.y <= -4.5f)
		{
			shotVec.x = 0.0f;
			shotVec.y = 0.0f;
			transform.position = new Vector3 (BeforeShot.transform.position.x,BeforeShot.transform.position.y,0.0f);
		}
	}


	void OnTriggerEnter2D(Collider2D _other)
	{
		if (_other.transform.tag == "Enemy")
		{
			transform.position = new Vector3 (BeforeShot.transform.position.x,BeforeShot.transform.position.y,0.0f);
		}
	}


}
