﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Water : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerStay2D(Collider2D _other)
	{
		//主人公が風当たり判定に接触した時の処理
		if (_other.transform.tag == "Player")
		{
			//ボール側のスクリプトにアクセス
			Ball ballScript = _other.gameObject.GetComponent<Ball>();




			ballScript.AddVec (new Vector3(0.0f,-1.0f,0.0f));
			ballScript.DivVecX ();

		}
	}
}
