﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageManager : SingletonBase<StageManager>{


	public List<GameObject> pSingleStagePrefab;
	List<GameObject> singleStageList = new List<GameObject>();


	int nowStage = 1;

	bool isNext = false;
	bool isMove = false;

	public bool GetIsNext(){ return isNext; }


	public void SetNextStage(){isNext = true;}
	public void TellMove(bool _flg){ isMove = _flg; }


	void Awake()
	{
		if (this != GetInstance)
		{
			Destroy (this);
			return;
		}
		DontDestroyOnLoad (this.gameObject);
	}


	// Use this for initialization
	void Start () 
	{
		
		GameObject stageObject = (GameObject)Instantiate 
			(
				pSingleStagePrefab[0],
				transform.position,
				Quaternion.identity
			);
		singleStageList.Add (stageObject);


		Debug.Log ("Add");
	}
	
	// Update is called once per frame
	void Update ()
	{
		NextStage ();

		AllStageMove();

	}


	void NextStage()
	{
		if (isNext == false)return;
		if (nowStage >= pSingleStagePrefab.Count)
		{
			//Debug.Log ("範囲外アクセス防止");
			return;
		}

		GameObject stageObject = (GameObject)Instantiate
			(
				pSingleStagePrefab[nowStage],
				transform.position,
				Quaternion.identity
			);

		singleStageList.Add (stageObject);





		nowStage++;
		isNext = false;


	}


	void AllStageMove()
	{
		//Debug.Log (isMove);
		//Debug.Log (singleStageList.Count);
		if (isMove == false)return;

		for (int sCnt = 0; sCnt < singleStageList.Count; sCnt++)
		{
			OneStage stageScript = singleStageList [sCnt].GetComponent<OneStage> ();
			if (stageScript == null)
			{
				Debug.LogError ("stageScriptNULL");
				continue;
			}
			stageScript.Move();
		}

	}

}
