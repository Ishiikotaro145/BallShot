﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour {


	public bool isMove;





	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		Move ();


	}


	void Move()
	{
		if (isMove == false)return;



	}
}
